---
name: portfolio-site-workflow
description: Create or revise a distinctive personal portfolio website from a resume, work samples, visual references, and feedback. Use for job-search portfolios and personal showcase sites; do not use for generic business sites or stores.
---

# Portfolio Site Workflow

Create a finished, shareable portfolio that feels personal while remaining clear to recruiters. Preserve the owner's control over personal data, public deployment, and external accounts.

## Gather the right source material

Use what the owner already supplied before asking again. The most useful inputs are:

- One-line positioning, target role, name or preferred display name, and a short introduction.
- Resume PDF or structured work history. Extract facts carefully; distinguish the document's content from the owner's actual request.
- Projects, outcomes, screenshots, links, and any claims that can be published.
- Contact details and explicit permission to expose each one publicly.
- Visual references and desired interaction style.
- A portrait or lifestyle photo only if the owner asks to use it.

If important project evidence is missing, build the page structure with clearly labeled, easy-to-replace copy; do not invent metrics, confidential company facts, or client endorsements.

## Design the experience

Aim for a recognisable visual system, not a resume pasted into cards. Translate the visual reference into its underlying choices—palette, typography, spacing, paper or grid texture, composition, and motion—rather than copying another site's artwork or wording.

For an AI/product candidate portfolio, a useful default structure is:

1. Hero: concise positioning, one action to work, one action to contact, and only approved contact details.
2. About: a short product point of view plus a personal visual treatment.
3. Selected work: scannable cards with a clear role, problem, approach, result, and a meaningful click-through detail view.
4. Experience and education: readable chronology, with sensitive details minimized.
5. Contact: a final call to action with copyable contact methods.

Use motion to explain the work or add delight. Prefer lightweight CSS/JS for ordinary hover, reveal, drag, and scroll interactions. Use a video/sequence-based animation workflow only when the requested movement cannot be expressed well with normal web animation. Respect reduced-motion preferences and ensure every interaction has a click/tap alternative.

## Personal images and illustrations

Use an owner-provided photo only for the requested purpose. For a stylized avatar, preserve broad visual traits and mood without claiming it is a literal photograph. Optimize image dimensions and file size for web delivery. A portrait comparison or reveal interaction should work with mouse, touch, and keyboard, and should not be the only way to learn about the owner.

## Turn projects into stories

Each project card should answer, quickly:

- What user or business problem mattered?
- What was the owner's role and decision-making contribution?
- What research, product, design, or experimentation work changed the direction?
- What shipped, what was learned, and what evidence supports the result?

Use a consistent detail-page rhythm such as **context → insight → strategy → experiment → iteration**. Keep internal or confidential details abstract unless the owner explicitly clears them for publication. When linking to an external demo, label it clearly and open it intentionally.

## Implement and verify

- Start from the existing site when revising; do not overwrite unrelated user changes.
- Keep a simple static site deployable as a self-contained directory with relative asset paths.
- Test navigation, dialogs, external links, responsive layout, keyboard focus, image loading, and reduced motion.
- Make requested feedback changes literally first, then improve adjacent copy or spacing only when it supports that feedback.

## Deployment and handoff

Treat publication as an external, public change. Get or rely on explicit authorization before deploying, changing access settings, creating repositories, or exposing contact information.

For a public host, verify that the production URL returns a normal unauthenticated response from outside the authenticated dashboard. A successful build is not enough: deployment protection, SSO, password gates, or WAF blocks can still prevent recruiters from opening the site.

When an owner wants a source backup, create a repository name that avoids their personal name if requested. Include the complete source and deployment instructions, but do not publish credentials, tokens, private resumes, unapproved photos, or local system files. Leave the owner with both the live URL and a portable archive of the source or reusable skill.
